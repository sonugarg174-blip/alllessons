i = 1
j = 1

while i <= 5: #outer loop
    print("\ni = ", i)
    j = 1
    while j <= 5: #inner loop
        print ("j = ", j)
        j += 1 #j = j + 1
    i += 1

