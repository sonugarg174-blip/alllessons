import math
print(math.sin(45))
print(math.cos(45))
print(math.tan(45))

print(math.ceil(45.390))
print(math.floor(45.390))
print(math.factorial(5))
print(math.copysign(-5, 8))
print(math.sqrt(25))
