#A
Set1 = {'green', 'blue'} 
Set2 = {'blue', 'yellow'}
print("Set 1:", Set1)
print("Set 2:", Set2)

print("Symmetric Difference :", Set1.symmetric_difference(Set2))

print("\n")
#B
Set1 = {1, 2, 3, 4, 5} 
Set2 = {1, 5, 6, 7, 8, 9}
print("Set 1:", Set1)
print("Set 2:", Set2)
print("Symmetric Difference :", Set1.symmetric_difference(Set2))

print("\n")