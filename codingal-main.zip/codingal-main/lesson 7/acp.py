
character = input("Enter a character:")
ascii = ord(character)
print(ascii)
