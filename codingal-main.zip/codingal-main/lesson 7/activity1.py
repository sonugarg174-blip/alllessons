a = 1827
b = 836
print(a is b)
print(a is not b)

x = 213.983
if type(x) is int:
    print("yes, x is an integer")
else:
    print("no, x is not an integer")

y = 746
if type(y) is not float:
    print("Not float")
else:
    print("float")

num1 = 50
num2 = 50
print(num1 is num2)

num3 = 2000
num4 = 2000
print(num3 is num4)