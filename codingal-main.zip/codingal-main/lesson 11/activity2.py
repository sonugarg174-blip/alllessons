# Write a program to check the infinite loop?
x = 0

while x < 2:
    print("Hello!")
