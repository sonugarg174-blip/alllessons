from tkinter import *

# Create window
window = Tk()

# Set the window title and geometry
window.title("Activity1 Window")
window.geometry('400x300')

window.mainloop()