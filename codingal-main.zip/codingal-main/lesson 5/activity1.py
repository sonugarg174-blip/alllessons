num = int(input("Please enter a number:"))
if num > 0:
    print(num,"is a positive number.")
