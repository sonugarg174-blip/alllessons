a = 16
b = 0
c = 3
if a and b and c:
    print("All the values have boolean as True.")
else:
    print("At least one of the values has the boolean of False.")

x = 15
y = -2
z = 0
if z > 0 or x < 15:
    print("Either one number has the boolean of True.")
else:
    print("Both numbers have the boolean of False.")