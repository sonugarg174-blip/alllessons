print("Does x equal y?")
x = 7343
y = 7834

if x != y:
    print("x does not equal y so it is:")
else:
    print("X does equal y so it is:")
print(x == y)

a = 986
b = 955

if (a == 985) != (b == 984):
    print("Hello")
else:
    print("Bye")