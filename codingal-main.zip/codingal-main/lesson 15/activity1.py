def greetings():
    print("Hello")
    print("How are you?")

greetings()

