def circumference():
    radius = int(input("Please enter the radius."))
    print("the circumference using the radius given is", pie * radius * 2)
pie = 3.14159
circumference()

