print("Hello")
print(12+34)
print("square of 5 is:", 5*5)
