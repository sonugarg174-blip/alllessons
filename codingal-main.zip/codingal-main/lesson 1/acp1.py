print("The quotent of 6 divided by 4 in integers is", int(6/4))
print("The remainder of the above is", 6%4)
print("However the full answer of the above is", 6/4)