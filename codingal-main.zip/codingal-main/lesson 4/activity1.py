#There are five trees in Jack's front yard. He checks each tree to find out how tall it is in inches and writes the height on a sheet of paper. Jack's list: 98, 94, 41, 96, and 11. What is the average height of a tree in Jack's front yard?

t1 = 98
t2 = 94
t3 = 41
t4 = 96
t5 = 11
 
total_height = t1 + t2 + t3 + t4 + t5 
avg = total_height / 5

print("The average height of a tree in jack's garden is", avg, "inches.")