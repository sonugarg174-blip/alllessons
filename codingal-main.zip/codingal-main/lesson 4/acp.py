print("/n 🧠 Square root finder 🧠/n")
num = int(input("Enter a number to find the square root of."))
squroot = num**0.5
print("The square root of", num, "is", squroot)