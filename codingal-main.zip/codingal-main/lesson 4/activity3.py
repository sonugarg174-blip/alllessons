# Raj scored 40, 70, 50 and 60 out of 100 in maths, science, Hindi and English. Find the percentage he got?

total = 100 * 4

maths = 40
science = 70
hindi = 50
english = 60

sum = maths + science + hindi + english
print("Raj scored", sum, "out of", total, "in total.")

percent = (sum / total) * 100
print("His percentage is", round(percent, 1), "%")