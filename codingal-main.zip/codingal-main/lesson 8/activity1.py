x = 4
y = 2
z = 10
v = 7
w = 5

result = (v + w) * x / y - z
print(result)