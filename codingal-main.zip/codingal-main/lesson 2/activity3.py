import keyword

print("All the keywords in python are listed below: \n")

print(keyword.kwlist)