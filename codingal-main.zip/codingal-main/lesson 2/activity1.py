name = "Soha"
year = 8
print(f"my name is {name} and i am in year {year}") 
print ("Hello", end=" ")
print("my name is Soha")
