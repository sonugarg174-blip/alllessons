superhero = "Flash"
real_name = "Barry Allen"
age = 21
superpower = "speed"
speed = 120 # km/s
power_level = (speed // age) * 5
 # Diplaying profile
print ("\n⚡SUPERHERO PROFILE⚡\n")
print("Superhero name:", superhero)
print("Real name:", real_name)
print("Age:", age)
print(f"Speed: {speed} !")
print("⚡POWER LEVEL⚡:", power_level)
