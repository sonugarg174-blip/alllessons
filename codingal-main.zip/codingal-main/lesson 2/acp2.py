your_birthday = input("When is your birthday?")
birthday1 = "3rd April"
birthday2 = "3rd February"
birthday3 = "13th February"
birthday4 = "13th June"
birthday5 = "19th February"

#display birthdays in a birthday profile
print("\n 🎂🥳BIRTHDAY PROFILE🥳🎂\n")
print(F"MY BIRTHDAY:  ❤️ {birthday1} ❤️ ")
print("SAMAH'S BIRTHDAY (my sister):", birthday2)
print("MY DAD'S BIRTHDAY:", birthday4)
print("MY MUM'S BIRTHDAY:", birthday5)
print("MY BEST FRIEND'S BIRTHDAY:", birthday3)
print("AND YOUR BIRTHDAY:", your_birthday)
