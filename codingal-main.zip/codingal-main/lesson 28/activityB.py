alist = [5, 6, 8, 2, 9]

enum_list = enumerate(alist)
print(list(enum_list)) # enumerated