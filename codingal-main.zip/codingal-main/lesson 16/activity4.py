# Doc string
def my_function():
    """This is my document string (docstring).
    This is a finction which takes no parameter and it returns None"""
    return None

print(my_function.__doc__)
