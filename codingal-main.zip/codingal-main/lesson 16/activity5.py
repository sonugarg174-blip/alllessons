# Optional arguments
def greet(name, message = "Hello"):
    print(message, name)

greet("Ripley")
greet("Alice", "Welcome")
