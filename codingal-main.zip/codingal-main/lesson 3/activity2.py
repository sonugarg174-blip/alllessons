a = 3.5
print("value:", a, "type:", type(a))
a_int = int (a)
print("value:", a_int, "type:", type(a_int))

age = int(input("What is your age?"))
print("Age:", age)

b = 0.0
print("value:", b, "type:", type(b))
b_bool = bool(b)
print("value:", b_bool, "type:", type(b_bool))

height = 45.678
print("value:", height, "type:", type(height))
height_str = str(height)
print("value:", height_str, "type:", type(height_str))

weight = float(input("What is your weight (include decimal points)?"))
print("Your weight is", weight)