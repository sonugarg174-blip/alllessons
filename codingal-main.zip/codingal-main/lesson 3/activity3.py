print("YOUR VERY OWN SPELL GENERATOR")

magical_word = input("Enter your magical word:")

firstspell = magical_word.upper

secondspell = magical_word * 7 

thirdspell = magical_word [ :4]

finalspell = thirdspell + " " + secondspell

print(finalspell)