congrats = input("congratulate your friend:")
congrats_upper = congrats.upper()
print(congrats_upper)