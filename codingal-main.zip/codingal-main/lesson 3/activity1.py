a = 9
print(type(a))

b = 5.7
print(type(b))

c = True
print(type(c))

d = "hello"
print(type(d))

